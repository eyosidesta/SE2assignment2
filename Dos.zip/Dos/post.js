const http = require('http');
const request = require('request');

var post = {
    url: 'http://www.sunstudiophotography.com',
    body: JSON.stringify({
        'name': 'test',
        'public': false
    }),
    dataType: 'json',
    headers: {
        'Content-Type': 'application/json',
    }
};

for (var i = 0; i < 1000; i++) {
    request.post(post, function(err, res, body) {
        if(!err && res.statusCode == 200) {
            console.log('successfully posted');
            console.log(body);
        }else {
            console.log('Error posting data');
        }
    });
}