const http = require('http');
const request = require('request');

//GET REQUEST
 for(var i = 0; i < 1000; i++) {
    request('http://www.google.com', function(err, res, body) {
        if(!err && res.statusCode == 200) {
            console.log('In');
            console.log(body);
            
        }
         else {
            console.log("Error Withe request");
        }
    });
}